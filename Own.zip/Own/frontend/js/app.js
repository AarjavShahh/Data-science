// =============================================
// PG Live — Core JavaScript Module
// =============================================

const API_BASE = '';

// API helper
async function api(url, options = {}) {
    const token = localStorage.getItem('token');
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const res = await fetch(API_BASE + url, { ...options, headers: { ...headers, ...options.headers } });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
}

// Auth state
function getUser() {
    try { return JSON.parse(localStorage.getItem('user')); } catch { return null; }
}

function isLoggedIn() { return !!localStorage.getItem('token'); }

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
}

// Toast notification
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}" style="font-size:1.2rem"></i><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
}

// Create PG Card HTML
function createPGCard(pg) {
    const amenities = typeof pg.amenities === 'string' ? JSON.parse(pg.amenities || '[]') : (pg.amenities || []);
    let starHTML = '';
    const fullStars = Math.floor(pg.rating || 0);
    const hasHalf = pg.rating % 1 >= 0.5;
    for (let i = 0; i < 5; i++) {
        if (i < fullStars) starHTML += '<i class="fas fa-star"></i>';
        else if (i === fullStars && hasHalf) starHTML += '<i class="fas fa-star-half-alt"></i>';
        else starHTML += '<i class="far fa-star"></i>';
    }

    const typeColors = { male: '#6C5CE7', female: '#E84393', coed: '#00B894' };
    const typeLabels = { male: 'Boys', female: 'Girls', coed: 'Co-ed' };

    return `
    <div class="card pg-card" onclick="window.location.href='/pages/listing-detail.html?id=${pg.id}'" style="cursor:pointer">
        <div class="card-img" style="background:linear-gradient(135deg,${typeColors[pg.pg_type] || '#6C5CE7'}22, #1A193288);display:flex;align-items:center;justify-content:center">
            <div style="text-align:center;padding:20px">
                <div style="font-size:3rem;margin-bottom:8px">
                    <i class="fas ${pg.pg_type === 'female' ? 'fa-home' : pg.pg_type === 'male' ? 'fa-building' : 'fa-city'}"></i>
                </div>
                <div style="font-size:1.1rem;font-weight:600;color:var(--text-primary)">${pg.title}</div>
                <div style="font-size:0.85rem;color:var(--text-secondary);margin-top:4px">${pg.area}, Ahmedabad</div>
            </div>
            ${pg.is_verified ? '<span class="pg-badge badge-verified"><i class="fas fa-check"></i> Verified</span>' : ''}
            <div class="pg-price">₹${pg.price_per_month?.toLocaleString()}<span>/mo</span></div>
        </div>
        <div class="card-body">
            <div class="pg-meta">
                <span class="pg-meta-item"><i class="fas fa-bed"></i> ${pg.room_type}</span>
                <span class="pg-meta-item" style="color:${typeColors[pg.pg_type] || '#6C5CE7'}">${typeLabels[pg.pg_type] || pg.pg_type}</span>
                <span class="pg-meta-item"><i class="fas fa-door-open"></i> ${pg.available_beds} beds</span>
            </div>
            <div class="pg-rating">
                <span class="stars">${starHTML}</span>
                <span class="rating-text">${pg.rating || 0} (${pg.total_reviews || 0} reviews)</span>
            </div>
            <div class="pg-amenities">
                ${amenities.slice(0, 4).map(a => `<span class="amenity-tag">${a}</span>`).join('')}
                ${amenities.length > 4 ? `<span class="amenity-tag">+${amenities.length - 4}</span>` : ''}
            </div>
        </div>
    </div>`;
}

// Update navbar based on auth state
function updateNavbar() {
    const navAuth = document.getElementById('navAuth');
    const navUser = document.getElementById('navUser');
    const user = getUser();

    if (user && navAuth && navUser) {
        navAuth.classList.add('hidden');
        navUser.classList.remove('hidden');
        const avatar = document.getElementById('userAvatar');
        const name = document.getElementById('userName');
        if (avatar) avatar.textContent = user.name?.charAt(0)?.toUpperCase() || 'U';
        if (name) name.textContent = user.name || 'User';

        const dashLink = document.getElementById('dashboardLink');
        if (dashLink) {
            if (user.role === 'admin') dashLink.href = '/pages/admin.html';
            else if (user.role === 'owner') dashLink.href = '/pages/dashboard-owner.html';
            else dashLink.href = '/pages/dashboard-tenant.html';
        }
    }
}

function toggleUserMenu() {
    const dd = document.getElementById('userDropdown');
    if (dd) dd.classList.toggle('hidden');
}

function toggleMobileMenu() {
    const nav = document.getElementById('navLinks');
    if (nav) nav.classList.toggle('open');
}

// Close dropdowns on outside click
document.addEventListener('click', (e) => {
    const dd = document.getElementById('userDropdown');
    const navUser = document.getElementById('navUser');
    if (dd && navUser && !navUser.contains(e.target)) {
        dd.classList.add('hidden');
    }
});

// Format date
function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Auth guard
function requireAuth(redirectTo = '/pages/login.html') {
    if (!isLoggedIn()) {
        window.location.href = redirectTo;
        return false;
    }
    return true;
}

function requireRole(role) {
    const user = getUser();
    if (!user || user.role !== role) {
        showToast('Access denied', 'error');
        window.location.href = '/';
        return false;
    }
    return true;
}

// Init
document.addEventListener('DOMContentLoaded', updateNavbar);
