const express = require('express');
const db = require('../../database/db');
const { authMiddleware, roleMiddleware } = require('../middleware/auth');

const router = express.Router();

// Get all listings with search/filter
router.get('/', (req, res) => {
    try {
        const { area, min_price, max_price, pg_type, room_type, amenity, search, sort } = req.query;

        let results = db.findAll('pg_listings', l => l.is_active === 1 || l.is_active === true);

        if (area) results = results.filter(l => l.area === area);
        if (min_price) results = results.filter(l => l.price_per_month >= parseInt(min_price));
        if (max_price) results = results.filter(l => l.price_per_month <= parseInt(max_price));
        if (pg_type) results = results.filter(l => l.pg_type === pg_type);
        if (room_type) results = results.filter(l => l.room_type === room_type);
        if (amenity) results = results.filter(l => (l.amenities || '').includes(amenity));
        if (search) {
            const s = search.toLowerCase();
            results = results.filter(l => (l.title || '').toLowerCase().includes(s) || (l.description || '').toLowerCase().includes(s) || (l.area || '').toLowerCase().includes(s));
        }

        // Sort
        if (sort === 'price_low') results.sort((a, b) => a.price_per_month - b.price_per_month);
        else if (sort === 'price_high') results.sort((a, b) => b.price_per_month - a.price_per_month);
        else if (sort === 'rating') results.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        else results.sort((a, b) => (b.is_verified || 0) - (a.is_verified || 0) || (b.rating || 0) - (a.rating || 0));

        // Attach owner info
        results = results.map(l => {
            const owner = db.findOne('users', u => u.id === l.owner_id);
            return { ...l, owner_name: owner?.name || 'Unknown', owner_phone: owner?.phone || '' };
        });

        res.json(results);
    } catch (err) {
        console.error('Listings error:', err);
        res.status(500).json({ error: 'Server error.' });
    }
});

// Get single listing
router.get('/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const listing = db.findOne('pg_listings', l => l.id === id);
        if (!listing) return res.status(404).json({ error: 'Listing not found.' });

        const owner = db.findOne('users', u => u.id === listing.owner_id);
        const images = db.findAll('pg_images', img => img.listing_id === id);
        const reviews = db.findAll('reviews', r => r.listing_id === id).map(r => {
            const user = db.findOne('users', u => u.id === r.user_id);
            return { ...r, user_name: user?.name || 'Anonymous' };
        }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        res.json({ ...listing, owner_name: owner?.name, owner_phone: owner?.phone, owner_email: owner?.email, images, reviews });
    } catch (err) {
        console.error('Listing detail error:', err);
        res.status(500).json({ error: 'Server error.' });
    }
});

// Create listing (owner only)
router.post('/', authMiddleware, roleMiddleware('owner'), (req, res) => {
    try {
        const { title, description, address, area, price_per_month, deposit, pg_type, room_type, total_beds, available_beds, amenities, rules } = req.body;
        if (!title || !address || !area || !price_per_month) return res.status(400).json({ error: 'Title, address, area, and price are required.' });

        const result = db.insert('pg_listings', {
            owner_id: req.user.id, title, description, address, area, city: 'Ahmedabad',
            price_per_month, deposit: deposit || 0, pg_type: pg_type || 'coed', room_type: room_type || 'double',
            total_beds: total_beds || 1, available_beds: available_beds || 1,
            amenities: typeof amenities === 'string' ? amenities : JSON.stringify(amenities || []),
            rules: rules || '', is_verified: 0, is_active: 1, rating: 0, total_reviews: 0
        });
        res.status(201).json({ message: 'Listing created!', id: result.lastInsertRowid });
    } catch (err) {
        console.error('Create listing error:', err);
        res.status(500).json({ error: 'Server error.' });
    }
});

// Update listing
router.put('/:id', authMiddleware, roleMiddleware('owner'), (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const listing = db.findOne('pg_listings', l => l.id === id && l.owner_id === req.user.id);
        if (!listing) return res.status(404).json({ error: 'Listing not found or unauthorized.' });

        const updates = {};
        const fields = ['title', 'description', 'address', 'area', 'price_per_month', 'deposit', 'pg_type', 'room_type', 'total_beds', 'available_beds', 'rules'];
        fields.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });
        if (req.body.amenities) updates.amenities = typeof req.body.amenities === 'string' ? req.body.amenities : JSON.stringify(req.body.amenities);

        db.update('pg_listings', l => l.id === id, updates);
        res.json({ message: 'Listing updated!' });
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

// Delete listing
router.delete('/:id', authMiddleware, roleMiddleware('owner', 'admin'), (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const listing = db.findOne('pg_listings', l => l.id === id);
        if (!listing) return res.status(404).json({ error: 'Listing not found.' });
        if (req.user.role === 'owner' && listing.owner_id !== req.user.id) return res.status(403).json({ error: 'Unauthorized.' });
        db.delete('pg_listings', l => l.id === id);
        res.json({ message: 'Listing deleted.' });
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

module.exports = router;
