const express = require('express');
const db = require('../../database/db');
const { authMiddleware, roleMiddleware } = require('../middleware/auth');

const router = express.Router();

router.post('/', authMiddleware, roleMiddleware('tenant'), (req, res) => {
    try {
        const { listing_id, move_in_date, message } = req.body;
        if (!listing_id) return res.status(400).json({ error: 'Listing ID is required.' });

        const listing = db.findOne('pg_listings', l => l.id === listing_id);
        if (!listing) return res.status(404).json({ error: 'Listing not found.' });
        if (listing.available_beds <= 0) return res.status(400).json({ error: 'No beds available.' });

        const existing = db.findOne('bookings', b => b.listing_id === listing_id && b.tenant_id === req.user.id && ['pending', 'accepted'].includes(b.status));
        if (existing) return res.status(400).json({ error: 'You already have an active booking for this PG.' });

        const result = db.insert('bookings', { listing_id, tenant_id: req.user.id, owner_id: listing.owner_id, status: 'pending', move_in_date: move_in_date || null, message: message || '' });
        db.insert('notifications', { user_id: listing.owner_id, title: 'New Booking Request', message: `${req.user.name} wants to book ${listing.title}`, type: 'booking', is_read: 0 });

        res.status(201).json({ message: 'Booking request sent!', id: result.lastInsertRowid });
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

router.get('/', authMiddleware, (req, res) => {
    try {
        let bookings;
        if (req.user.role === 'tenant') {
            bookings = db.findAll('bookings', b => b.tenant_id === req.user.id);
        } else if (req.user.role === 'owner') {
            bookings = db.findAll('bookings', b => b.owner_id === req.user.id);
        } else {
            bookings = db.findAll('bookings');
        }

        bookings = bookings.map(b => {
            const listing = db.findOne('pg_listings', l => l.id === b.listing_id);
            const tenant = db.findOne('users', u => u.id === b.tenant_id);
            const owner = db.findOne('users', u => u.id === b.owner_id);
            return { ...b, listing_title: listing?.title, area: listing?.area, price_per_month: listing?.price_per_month, tenant_name: tenant?.name, tenant_phone: tenant?.phone, owner_name: owner?.name };
        }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        res.json(bookings);
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

router.put('/:id', authMiddleware, roleMiddleware('owner'), (req, res) => {
    try {
        const { status } = req.body;
        if (!['accepted', 'rejected'].includes(status)) return res.status(400).json({ error: 'Status must be accepted or rejected.' });

        const id = parseInt(req.params.id);
        const booking = db.findOne('bookings', b => b.id === id && b.owner_id === req.user.id);
        if (!booking) return res.status(404).json({ error: 'Booking not found.' });

        db.update('bookings', b => b.id === id, { status });
        if (status === 'accepted') {
            const listing = db.findOne('pg_listings', l => l.id === booking.listing_id);
            if (listing && listing.available_beds > 0) db.update('pg_listings', l => l.id === booking.listing_id, { available_beds: listing.available_beds - 1 });
        }

        const listing = db.findOne('pg_listings', l => l.id === booking.listing_id);
        db.insert('notifications', { user_id: booking.tenant_id, title: `Booking ${status}`, message: `Your booking for ${listing?.title || 'PG'} has been ${status}.`, type: 'booking', is_read: 0 });
        res.json({ message: `Booking ${status}.` });
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

module.exports = router;
