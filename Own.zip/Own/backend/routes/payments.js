const express = require('express');
const db = require('../../database/db');
const { authMiddleware } = require('../middleware/auth');
const crypto = require('crypto');

const router = express.Router();

router.post('/create-order', authMiddleware, (req, res) => {
    try {
        const { amount, payment_type, booking_id } = req.body;
        if (!amount || !payment_type) return res.status(400).json({ error: 'Amount and payment type are required.' });

        const transactionId = 'TXN_' + crypto.randomBytes(8).toString('hex').toUpperCase();
        const result = db.insert('payments', { user_id: req.user.id, booking_id: booking_id || null, amount, payment_type, transaction_id: transactionId, status: 'pending' });

        res.json({ order_id: result.lastInsertRowid, transaction_id: transactionId, amount, currency: 'INR', status: 'created' });
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

router.post('/verify', authMiddleware, (req, res) => {
    try {
        const { transaction_id } = req.body;
        if (!transaction_id) return res.status(400).json({ error: 'Transaction ID is required.' });

        const payment = db.findOne('payments', p => p.transaction_id === transaction_id && p.user_id === req.user.id);
        if (!payment) return res.status(404).json({ error: 'Payment not found.' });

        db.update('payments', p => p.id === payment.id, { status: 'completed' });
        res.json({ message: 'Payment verified successfully!', status: 'completed' });
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

router.get('/history', authMiddleware, (req, res) => {
    try {
        const payments = db.findAll('payments', p => p.user_id === req.user.id).map(p => {
            if (p.booking_id) {
                const booking = db.findOne('bookings', b => b.id === p.booking_id);
                const listing = booking ? db.findOne('pg_listings', l => l.id === booking.listing_id) : null;
                return { ...p, listing_title: listing?.title };
            }
            return p;
        }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        res.json(payments);
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

module.exports = router;
