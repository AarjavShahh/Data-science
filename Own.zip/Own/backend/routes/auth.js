const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../../database/db');
const { authMiddleware } = require('../middleware/auth');
require('dotenv').config();

const router = express.Router();

router.post('/register', (req, res) => {
    try {
        const { name, email, password, phone, role } = req.body;
        if (!name || !email || !password || !role) return res.status(400).json({ error: 'Name, email, password, and role are required.' });
        if (!['tenant', 'owner'].includes(role)) return res.status(400).json({ error: 'Role must be tenant or owner.' });

        const existing = db.findOne('users', u => u.email === email);
        if (existing) return res.status(400).json({ error: 'Email already registered.' });

        const hashedPassword = bcrypt.hashSync(password, 10);
        const result = db.insert('users', { name, email, password: hashedPassword, phone: phone || null, role });

        const token = jwt.sign({ id: result.lastInsertRowid, email, role, name }, process.env.JWT_SECRET, { expiresIn: '7d' });
        res.status(201).json({ message: 'Registration successful!', token, user: { id: result.lastInsertRowid, name, email, role, phone } });
    } catch (err) {
        console.error('Register error:', err);
        res.status(500).json({ error: 'Server error during registration.' });
    }
});

router.post('/login', (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

        const user = db.findOne('users', u => u.email === email);
        if (!user) return res.status(401).json({ error: 'Invalid email or password.' });

        if (!bcrypt.compareSync(password, user.password)) return res.status(401).json({ error: 'Invalid email or password.' });

        const token = jwt.sign({ id: user.id, email: user.email, role: user.role, name: user.name }, process.env.JWT_SECRET, { expiresIn: '7d' });
        res.json({ message: 'Login successful!', token, user: { id: user.id, name: user.name, email: user.email, role: user.role, phone: user.phone } });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ error: 'Server error during login.' });
    }
});

router.get('/profile', authMiddleware, (req, res) => {
    try {
        const user = db.findOne('users', u => u.id === req.user.id);
        if (!user) return res.status(404).json({ error: 'User not found.' });
        const { password, ...safe } = user;
        res.json(safe);
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

module.exports = router;
