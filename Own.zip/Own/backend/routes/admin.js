const express = require('express');
const db = require('../../database/db');
const { authMiddleware, roleMiddleware } = require('../middleware/auth');

const router = express.Router();

router.get('/users', authMiddleware, roleMiddleware('admin'), (req, res) => {
    try {
        const users = db.findAll('users').map(({ password, ...u }) => u).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        res.json(users);
    } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/listings', authMiddleware, roleMiddleware('admin'), (req, res) => {
    try {
        const listings = db.findAll('pg_listings').map(l => {
            const owner = db.findOne('users', u => u.id === l.owner_id);
            return { ...l, owner_name: owner?.name || 'Unknown' };
        }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        res.json(listings);
    } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.put('/listings/:id/verify', authMiddleware, roleMiddleware('admin'), (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const listing = db.findOne('pg_listings', l => l.id === id);
        if (!listing) return res.status(404).json({ error: 'Listing not found.' });
        const newStatus = listing.is_verified ? 0 : 1;
        db.update('pg_listings', l => l.id === id, { is_verified: newStatus });
        res.json({ message: newStatus ? 'Listing verified!' : 'Verification removed.', is_verified: newStatus });
    } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.delete('/listings/:id', authMiddleware, roleMiddleware('admin'), (req, res) => {
    try {
        db.delete('pg_listings', l => l.id === parseInt(req.params.id));
        res.json({ message: 'Listing removed.' });
    } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.delete('/users/:id', authMiddleware, roleMiddleware('admin'), (req, res) => {
    try {
        if (parseInt(req.params.id) === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself.' });
        db.delete('users', u => u.id === parseInt(req.params.id));
        res.json({ message: 'User removed.' });
    } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/stats', authMiddleware, roleMiddleware('admin'), (req, res) => {
    try {
        res.json({
            totalUsers: db.count('users'),
            totalListings: db.count('pg_listings'),
            totalBookings: db.count('bookings'),
            totalPayments: db.sum('payments', 'amount', p => p.status === 'completed'),
            verifiedListings: db.count('pg_listings', l => l.is_verified === 1),
            pendingBookings: db.count('bookings', b => b.status === 'pending')
        });
    } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/notifications', authMiddleware, (req, res) => {
    try {
        const notifs = db.findAll('notifications', n => n.user_id === req.user.id).sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 20);
        res.json(notifs);
    } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

module.exports = router;
