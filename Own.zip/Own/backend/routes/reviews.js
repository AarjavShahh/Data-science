const express = require('express');
const db = require('../../database/db');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

router.get('/:listingId', (req, res) => {
    try {
        const lid = parseInt(req.params.listingId);
        const reviews = db.findAll('reviews', r => r.listing_id === lid).map(r => {
            const user = db.findOne('users', u => u.id === r.user_id);
            return { ...r, user_name: user?.name || 'Anonymous' };
        }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        res.json(reviews);
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

router.post('/', authMiddleware, (req, res) => {
    try {
        const { listing_id, rating, comment } = req.body;
        if (!listing_id || !rating) return res.status(400).json({ error: 'Listing ID and rating are required.' });
        if (rating < 1 || rating > 5) return res.status(400).json({ error: 'Rating must be between 1 and 5.' });

        const existing = db.findOne('reviews', r => r.listing_id === listing_id && r.user_id === req.user.id);
        if (existing) return res.status(400).json({ error: 'You have already reviewed this PG.' });

        db.insert('reviews', { listing_id, user_id: req.user.id, rating, comment: comment || '' });

        // Update listing rating
        const allReviews = db.findAll('reviews', r => r.listing_id === listing_id);
        const avgRating = Math.round((allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length) * 10) / 10;
        db.update('pg_listings', l => l.id === listing_id, { rating: avgRating, total_reviews: allReviews.length });

        res.status(201).json({ message: 'Review added!' });
    } catch (err) {
        res.status(500).json({ error: 'Server error.' });
    }
});

module.exports = router;
