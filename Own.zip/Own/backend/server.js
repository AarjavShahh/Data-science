require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const initDB = require('../database/seed');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: '*', methods: ['GET', 'POST'] }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend static files
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Serve uploaded images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/listings', require('./routes/listings'));
app.use('/api/reviews', require('./routes/reviews'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/admin', require('./routes/admin'));

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// SPA fallback — serve index.html for non-API routes
app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
        res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
    }
});

// =====================
// WebRTC Signaling
// =====================
const rooms = new Map();

io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join-room', ({ roomId, userId, userName }) => {
        socket.join(roomId);
        socket.userId = userId;
        socket.userName = userName;
        socket.roomId = roomId;

        if (!rooms.has(roomId)) {
            rooms.set(roomId, new Set());
        }
        rooms.get(roomId).add(socket.id);

        // Notify others in room
        socket.to(roomId).emit('user-joined', {
            socketId: socket.id,
            userId,
            userName
        });

        console.log(`${userName} joined room ${roomId}`);
    });

    socket.on('offer', ({ to, offer }) => {
        io.to(to).emit('offer', { from: socket.id, offer, userName: socket.userName });
    });

    socket.on('answer', ({ to, answer }) => {
        io.to(to).emit('answer', { from: socket.id, answer });
    });

    socket.on('ice-candidate', ({ to, candidate }) => {
        io.to(to).emit('ice-candidate', { from: socket.id, candidate });
    });

    socket.on('end-call', () => {
        if (socket.roomId) {
            socket.to(socket.roomId).emit('call-ended', { userName: socket.userName });
            const room = rooms.get(socket.roomId);
            if (room) {
                room.delete(socket.id);
                if (room.size === 0) rooms.delete(socket.roomId);
            }
        }
    });

    socket.on('disconnect', () => {
        if (socket.roomId) {
            socket.to(socket.roomId).emit('user-left', { userName: socket.userName });
            const room = rooms.get(socket.roomId);
            if (room) {
                room.delete(socket.id);
                if (room.size === 0) rooms.delete(socket.roomId);
            }
        }
        console.log('User disconnected:', socket.id);
    });
});

// Initialize database and start server
const PORT = process.env.PORT || 3000;

initDB();

server.listen(PORT, () => {
    console.log(`\n🏠 PG Live Server running at http://localhost:${PORT}`);
    console.log(`📡 WebSocket signaling active`);
    console.log(`\n--- Demo Accounts ---`);
    console.log(`Admin:  admin@pglive.com / password123`);
    console.log(`Owner:  rajesh@pglive.com / password123`);
    console.log(`Tenant: rohit@gmail.com / password123`);
    console.log(`-----------------------\n`);
});
