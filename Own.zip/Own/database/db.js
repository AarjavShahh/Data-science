const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'pglive.json');

// Default empty database structure
const DEFAULT_DB = {
    users: [],
    pg_listings: [],
    pg_images: [],
    reviews: [],
    bookings: [],
    payments: [],
    video_sessions: [],
    notifications: [],
    _counters: { users: 0, pg_listings: 0, pg_images: 0, reviews: 0, bookings: 0, payments: 0, video_sessions: 0, notifications: 0 }
};

class JsonDB {
    constructor() {
        if (fs.existsSync(DB_PATH)) {
            try {
                this.data = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
            } catch {
                this.data = JSON.parse(JSON.stringify(DEFAULT_DB));
            }
        } else {
            this.data = JSON.parse(JSON.stringify(DEFAULT_DB));
        }
    }

    save() {
        fs.writeFileSync(DB_PATH, JSON.stringify(this.data, null, 2));
    }

    // Insert a record, returns { lastInsertRowid }
    insert(table, record) {
        this.data._counters[table] = (this.data._counters[table] || 0) + 1;
        const id = this.data._counters[table];
        const newRecord = { id, ...record, created_at: record.created_at || new Date().toISOString() };
        this.data[table].push(newRecord);
        this.save();
        return { lastInsertRowid: id };
    }

    // Find all records, optional filter function
    findAll(table, filterFn) {
        const records = this.data[table] || [];
        return filterFn ? records.filter(filterFn) : [...records];
    }

    // Find one record
    findOne(table, filterFn) {
        return (this.data[table] || []).find(filterFn) || null;
    }

    // Update records matching filter
    update(table, filterFn, updates) {
        let updated = 0;
        this.data[table] = (this.data[table] || []).map(record => {
            if (filterFn(record)) {
                updated++;
                return { ...record, ...updates };
            }
            return record;
        });
        if (updated > 0) this.save();
        return { changes: updated };
    }

    // Delete records matching filter
    delete(table, filterFn) {
        const before = this.data[table]?.length || 0;
        this.data[table] = (this.data[table] || []).filter(r => !filterFn(r));
        const deleted = before - this.data[table].length;
        if (deleted > 0) this.save();
        return { changes: deleted };
    }

    // Count records
    count(table, filterFn) {
        if (filterFn) return this.findAll(table, filterFn).length;
        return (this.data[table] || []).length;
    }

    // Aggregate: average
    avg(table, field, filterFn) {
        const records = filterFn ? this.findAll(table, filterFn) : this.data[table] || [];
        if (records.length === 0) return 0;
        const sum = records.reduce((s, r) => s + (r[field] || 0), 0);
        return sum / records.length;
    }

    // Aggregate: sum
    sum(table, field, filterFn) {
        const records = filterFn ? this.findAll(table, filterFn) : this.data[table] || [];
        return records.reduce((s, r) => s + (r[field] || 0), 0);
    }
}

module.exports = new JsonDB();
