const db = require('./db');
const path = require('path');
const bcrypt = require(path.join(__dirname, '..', 'backend', 'node_modules', 'bcryptjs'));

function initDB() {
    // Check if already seeded
    if (db.count('users') > 0) {
        console.log('Database already seeded.');
        return;
    }

    const hash = bcrypt.hashSync('password123', 10);

    // Admin
    db.insert('users', { name: 'Admin', email: 'admin@pglive.com', password: hash, phone: '9999999999', role: 'admin' });

    // PG Owners
    const owners = [
        { name: 'Rajesh Patel', email: 'rajesh@pglive.com', phone: '9876543210' },
        { name: 'Meena Shah', email: 'meena@pglive.com', phone: '9876543211' },
        { name: 'Amit Desai', email: 'amit@pglive.com', phone: '9876543212' },
        { name: 'Priya Mehta', email: 'priya@pglive.com', phone: '9876543213' },
        { name: 'Suresh Joshi', email: 'suresh@pglive.com', phone: '9876543214' },
        { name: 'Kavita Sharma', email: 'kavita@pglive.com', phone: '9876543215' },
        { name: 'Deepak Nair', email: 'deepak@pglive.com', phone: '9876543216' },
        { name: 'Anita Verma', email: 'anita@pglive.com', phone: '9876543217' },
    ];
    owners.forEach(o => db.insert('users', { ...o, password: hash, role: 'owner' }));

    // Tenants
    const tenants = [
        { name: 'Rohit Kumar', email: 'rohit@gmail.com', phone: '9001234567' },
        { name: 'Sneha Gupta', email: 'sneha@gmail.com', phone: '9001234568' },
        { name: 'Vikram Singh', email: 'vikram@gmail.com', phone: '9001234569' },
    ];
    tenants.forEach(t => db.insert('users', { ...t, password: hash, role: 'tenant' }));

    // PG Listings
    const listings = [
        { owner_id: 2, title: 'Patel Premium PG', description: 'Spacious rooms with AC, Wi-Fi, and homely meals. Located near Gujarat University with excellent connectivity to SG Highway.', address: '23, Navrangpura Main Road', area: 'Navrangpura', city: 'Ahmedabad', price_per_month: 8500, deposit: 5000, pg_type: 'male', room_type: 'double', total_beds: 20, available_beds: 5, amenities: '["WiFi","AC","Meals","Laundry","Parking","CCTV","Power Backup"]', rules: 'No smoking. Gate closes at 11 PM.', is_verified: 1, is_active: 1, rating: 4.5, total_reviews: 12 },
        { owner_id: 3, title: 'Shah Girls Hostel', description: 'Safe and secure accommodation for working women and students. 24/7 security, home-cooked meals, and walking distance to CG Road.', address: '45, Satellite Road', area: 'Satellite', city: 'Ahmedabad', price_per_month: 7000, deposit: 4000, pg_type: 'female', room_type: 'double', total_beds: 30, available_beds: 8, amenities: '["WiFi","AC","Meals","Laundry","CCTV","Power Backup","Water Purifier"]', rules: 'Girls only. Visitors allowed till 8 PM.', is_verified: 1, is_active: 1, rating: 4.7, total_reviews: 18 },
        { owner_id: 4, title: 'Desai Student PG', description: 'Affordable PG for students near LD Engineering College. Clean rooms, study area, and mess facility available.', address: '12, Navrangpura Society', area: 'Navrangpura', city: 'Ahmedabad', price_per_month: 5500, deposit: 3000, pg_type: 'coed', room_type: 'triple', total_beds: 40, available_beds: 12, amenities: '["WiFi","Meals","Study Room","Parking","Water Purifier"]', rules: 'No alcohol. Quiet hours after 10 PM.', is_verified: 0, is_active: 1, rating: 4.0, total_reviews: 8 },
        { owner_id: 5, title: 'Mehta Luxury PG', description: 'Premium living with single occupancy rooms, attached bathrooms, housekeeping, and gym access. Perfect for working professionals.', address: '78, SG Highway Service Road', area: 'SG Highway', city: 'Ahmedabad', price_per_month: 14000, deposit: 10000, pg_type: 'male', room_type: 'single', total_beds: 15, available_beds: 3, amenities: '["WiFi","AC","Meals","Gym","Laundry","CCTV","Housekeeping","Power Backup","Attached Bathroom"]', rules: 'Professional atmosphere. No pets.', is_verified: 1, is_active: 1, rating: 4.8, total_reviews: 22 },
        { owner_id: 6, title: 'Joshi Budget PG', description: 'Clean and affordable staying with basic amenities. Good for students looking for pocket-friendly accommodation near IIM Ahmedabad.', address: '34, Vastrapur Lake Road', area: 'Vastrapur', city: 'Ahmedabad', price_per_month: 4500, deposit: 2000, pg_type: 'male', room_type: 'dormitory', total_beds: 50, available_beds: 15, amenities: '["WiFi","Meals","Parking","Water Purifier"]', rules: 'Shared facilities. Maintain hygiene.', is_verified: 0, is_active: 1, rating: 3.8, total_reviews: 6 },
        { owner_id: 7, title: 'Kavita Women PG', description: 'Elegant women-only PG with beautiful interiors, rooftop garden, and organic meals. Near Bodakdev commercial area.', address: '56, Bodakdev Main Road', area: 'Bodakdev', city: 'Ahmedabad', price_per_month: 9500, deposit: 6000, pg_type: 'female', room_type: 'double', total_beds: 24, available_beds: 6, amenities: '["WiFi","AC","Organic Meals","Laundry","CCTV","Power Backup","Rooftop","Library"]', rules: 'Ladies only. No male visitors.', is_verified: 1, is_active: 1, rating: 4.6, total_reviews: 15 },
        { owner_id: 8, title: 'Nair Tech PG', description: 'Designed for IT professionals. High-speed internet, ergonomic workstations, and proximity to GIFT City shuttle point.', address: '89, Prahlad Nagar Garden Road', area: 'Prahlad Nagar', city: 'Ahmedabad', price_per_month: 11000, deposit: 7000, pg_type: 'coed', room_type: 'single', total_beds: 18, available_beds: 4, amenities: '["High-Speed WiFi","AC","Meals","Workstation","Laundry","CCTV","Power Backup","Co-working Space"]', rules: 'Professional environment. Quiet after 11 PM.', is_verified: 1, is_active: 1, rating: 4.4, total_reviews: 10 },
        { owner_id: 9, title: 'Verma Family PG', description: 'Homely atmosphere with family-style living. Home-cooked Gujarati and North Indian meals. Walking distance from Thaltej Cross Roads.', address: '67, Thaltej-Shilaj Road', area: 'Thaltej', city: 'Ahmedabad', price_per_month: 7500, deposit: 4000, pg_type: 'coed', room_type: 'double', total_beds: 25, available_beds: 7, amenities: '["WiFi","Home Meals","Laundry","Parking","Power Backup","Garden","Common Room"]', rules: 'Family-friendly. No loud music.', is_verified: 0, is_active: 1, rating: 4.2, total_reviews: 9 },
    ];
    listings.forEach(l => db.insert('pg_listings', l));

    // Images
    for (let i = 1; i <= 8; i++) {
        db.insert('pg_images', { listing_id: i, image_url: `/images/pg${i}_1.jpg`, is_primary: 1 });
        db.insert('pg_images', { listing_id: i, image_url: `/images/pg${i}_2.jpg`, is_primary: 0 });
    }

    // Reviews
    const reviews = [
        { listing_id: 1, user_id: 10, rating: 5, comment: 'Excellent PG! Clean rooms and tasty food. Highly recommended for students.' },
        { listing_id: 1, user_id: 11, rating: 4, comment: 'Good location and facilities. WiFi could be faster though.' },
        { listing_id: 2, user_id: 11, rating: 5, comment: 'Best girls PG in Satellite area. Very safe and well-maintained.' },
        { listing_id: 2, user_id: 12, rating: 4, comment: 'Lovely place. The food quality is amazing. Slightly expensive.' },
        { listing_id: 4, user_id: 10, rating: 5, comment: 'Premium experience! Worth every penny. The gym is great.' },
        { listing_id: 6, user_id: 11, rating: 5, comment: 'Beautiful interiors and the rooftop garden is so peaceful.' },
        { listing_id: 7, user_id: 12, rating: 4, comment: 'Great internet speed. Perfect for remote work.' },
        { listing_id: 8, user_id: 10, rating: 4, comment: 'Very homely. Aunty makes the best dal-chawal!' },
    ];
    reviews.forEach(r => db.insert('reviews', r));

    console.log('Database seeded successfully!');
}

module.exports = initDB;

if (require.main === module) {
    initDB();
}
