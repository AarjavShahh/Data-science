project idea: Name PG Live

Prompt:
Design and develop a full-stack web application that enables users to find reliable and verified Paying Guest (PG) 
accommodations when relocating to a new city. The platform should solve the problem of misleading or fabricated 
images in PG listings by incorporating a real-time live video verification system.
The application must be built using HTML, CSS, and JavaScript for the frontend, and a suitable backend 
framework (such as Node.js/Express or Django/Flask) connected to a database (MySQL) for storing 
user data, listings, and transactions.

🎯 Core Objective
To create a transparent, trustworthy, and user-friendly platform that allows users to verify PG accommodations 
in real-time, eliminating fake listings and improving decision-making.

🚀 Key Functional Requirements
👤 User Module (Tenants/Employees)
User registration and login (authentication system)
Search PGs based on location, price, amenities, and ratings
Location is Ahmedabad. Include some random pg owner of Ahmedabad with photos.
View PG details with images, description, and reviews
Initiate live video calls with PG owners for real-time verification
Post accommodation requirements by paying a minimal registration fee
Secure online payment integration

🏠 PG Owner Module
Register and create PG listings
Upload images, pricing, facilities, and rules
Accept/respond to tenant requests
Participate in live video calls with users
Manage bookings and inquiries through a dashboard

🎥 Live Verification Feature
Integration of real-time video calling (WebRTC or third-party APIs like Zoom/Agora)
Enable one-to-one video interaction between tenant and PG owner
Optional recording or snapshot feature for proof of authenticity

💳 Payment System
Integration with a payment gateway (e.g., Razorpay/Stripe)
Allow users to pay a small fee to post accommodation requirements
Maintain transaction records in the database

⭐ Additional Features
Review and rating system for PGs
Location-based(Ahmedabad) filtering (maps integration optional)
Admin panel to monitor users, listings, and complaints
Verification badge for trusted PGs
Notification system (email/SMS)

🛠️ Technical Requirements
Frontend:
HTML, CSS, JavaScript (optionally React.js)
Responsive UI design
Backend:
Node.js with Express / Python with Flask or Django
RESTful APIs for communication between frontend and backend
Database:
MySQL
Store users, PG listings, payments, and reviews
Other Integrations:
WebRTC / Video API for live calls
Payment Gateway API
Authentication (JWT / Sessions)

📊 Expected Outcome
A fully functional web application that:
Eliminates fake PG listings
Enables real-time property verification via live video
Provides a seamless and secure experience for both tenants and PG owners